﻿using System;
using Verse;
using RimWorld;

namespace RimWorldUtils
{
	public class SpecialThingFilterWorker_Fresh : SpecialThingFilterWorker
	{
		public override bool Matches(Thing t)
		{
			ThingWithComps thingWithComps = t as ThingWithComps;
			if (thingWithComps == null)
			{
				return false;
			}
			CompRottable comp = thingWithComps.GetComp<CompRottable>();
			return comp != null && comp.Stage == RotStage.Fresh;
		}

		public override bool PotentiallyMatches(ThingDef def)
		{
			return def.HasComp(typeof(CompRottable));
		}
	}
}

