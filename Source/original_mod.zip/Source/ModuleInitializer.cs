using System.Reflection;

using Verse;
using RimWorld;

namespace RimWorldUtils
{
	[StaticConstructorOnStartup]
    internal static class ModuleInitializer
    {
		/* actually, since RimWorld can be told to run static constructors, we don't need module initializers after all... */
        internal static void Run()
        {
			Log.Message("Muzzy's RimWorld utils loading!");

			MethodInfo orig_DrawColonist = typeof(ColonistBar).GetMethod("DrawColonist", BindingFlags.Instance | BindingFlags.NonPublic);
			MethodInfo my_DrawColonist = typeof(_ColonistBar).GetMethod("_DrawColonist", BindingFlags.Static | BindingFlags.NonPublic);
			Detours.TryDetourFromTo(orig_DrawColonist, my_DrawColonist);
		}

		static ModuleInitializer()
		{
			//Log.Error("Muzzy testing static cctor");

		}
    }
}