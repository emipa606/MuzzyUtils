﻿using System;
using Verse;
using RimWorld;
using UnityEngine;
using System.Reflection;
using System.Collections.Generic;

namespace System.Runtime.CompilerServices
{
	[AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Class
		 | AttributeTargets.Method)]
	public sealed class ExtensionAttribute : Attribute { }
}

namespace RimWorldUtils
{
	[StaticConstructorOnStartup]
	internal static class _ColonistBar
	{
		// FOO

		private static readonly Texture2D MoodTex = SolidColorMaterials.NewSolidColorTexture (new Color(0.2f, 0.8f, 0.85f, 0.5f));
		private static readonly Texture2D MoodMinorCrossedTex = SolidColorMaterials.NewSolidColorTexture(new Color(0.85f, 0.85f, 0.2f, 0.5f));
		private static readonly Texture2D MoodMajorCrossedTex = SolidColorMaterials.NewSolidColorTexture(new Color(0.95f, 0.55f, 0.05f, 0.75f));
		private static readonly Texture2D MoodExtremeCrossedTex = SolidColorMaterials.NewSolidColorTexture(new Color(0.95f, 0.15f, 0.00f, 0.8f));
		private static readonly Texture2D MoodExtremeCrossedBGTex = SolidColorMaterials.NewSolidColorTexture(new Color(0.9f, 0.1f, 0.00f, 0.45f));

		private static readonly Texture2D MoodTargetTex = SolidColorMaterials.NewSolidColorTexture(new Color(0.7f, 0.9f, 0.95f, 0.7f));
		private static readonly Texture2D MoodBreakTex = SolidColorMaterials.NewSolidColorTexture(new Color(0.1f, 0.2f, 0.22f, 0.8f));
		//private static readonly Texture2D MoodBreakCrossedTex = SolidColorMaterials.NewSolidColorTexture(new Color(0.9f, 0.1f, 0.1f, 0.8f));

		// ...
		private static readonly Texture2D BGTex = Command.BGTex;
		private static readonly Texture2D DeadColonistTex = ContentFinder<Texture2D>.Get("UI/Misc/DeadColonist", true);

		private static readonly Vector3 PawnTextureCameraOffset = new Vector3(0f, 0f, 0.3f);

		internal static System.Object InvokeOriginal(String name, ColonistBar cbar, System.Object[] args)
		{
			return typeof(ColonistBar).GetMethod(name, BindingFlags.Instance | BindingFlags.NonPublic).Invoke(cbar, args);
		}

		internal static System.Object GetOriginal(String name, ColonistBar cbar)
		{
			return typeof(ColonistBar).GetField(name, BindingFlags.Instance | BindingFlags.NonPublic).GetValue(cbar);
		}

		private static float GetColonistRectAlpha(Rect rect)
		{
			float t;
			if (Messages.CollidesWithAnyMessage(rect, out t))
			{
				return Mathf.Lerp(1f, 0.2f, t);
			}
			return 1f;
		}

		private static float SpacingHorizontalAssumingScale(float scale)
		{
			return 24f * scale;
		}

		private static int GetAllowedRowsCountForScale(float scale)
		{
			if (scale > 0.58f)
			{
				return 1;
			}
			if (scale > 0.42f)
			{
				return 2;
			}
			return 3;
		}

		private static float calculateScale(ColonistBar cbar) {
			float num = 1f;
			while (true)
			{
				int allowedRowsCountForScale = GetAllowedRowsCountForScale(num);
				int num2 = (int)InvokeOriginal("RowsCountAssumingScale", cbar, new System.Object[] { num });
				if (num2 <= allowedRowsCountForScale)
				{
					break;
				}
				num *= 0.95f;
			}
			return num;
		}
		/*
		private Rect GetPawnTextureRect(float x, float y, scale)
		{
			Vector2 vector = ColonistBar.PawnTextureSize * scale;
			return new Rect(x + 1f, y - (vector.y - this.Size.y) - 1f, vector.x, vector.y);
		}
*/
		internal static void DrawMentalThreshold(Rect moodRect, float threshold, float currentMood)
		{
			GUI.DrawTexture(new Rect(moodRect.x, moodRect.yMax - moodRect.height * threshold, moodRect.width, 1), MoodBreakTex);
			/*if (currentMood <= threshold)
			{
				GUI.DrawTexture(new Rect(moodRect.xMax-4, moodRect.yMax - moodRect.height * threshold, 8, 2), MoodBreakCrossedTex);
			}*/
		}

		internal static void _DrawColonist(this ColonistBar cbar, Rect rect, Pawn colonist)
		{
			float scale = calculateScale(cbar);
			float colonistRectAlpha = GetColonistRectAlpha(rect);
			bool flag = (!colonist.Dead) ? Find.Selector.SelectedObjects.Contains(colonist) : Find.Selector.SelectedObjects.Contains(colonist.corpse);
			Color color = new Color(1f, 1f, 1f, colonistRectAlpha);
			GUI.color = color;

			// draw mood border
			Rect moodBorderRect = rect.ContractedBy(-1f);
			Need_Mood mood = (!colonist.Dead) ? colonist.needs.mood : null;
			MentalBreaker mb = (!colonist.Dead) ? colonist.mindState.mentalBreaker : null;

			if (mood != null && mb != null)
			{
				if (mood.CurLevelPercentage <= mb.BreakThresholdExtreme)
				{
					GUI.DrawTexture(moodBorderRect, MoodExtremeCrossedTex);
				}
				else if (mood.CurLevelPercentage <= mb.BreakThresholdMajor)
				{
					GUI.DrawTexture(moodBorderRect, MoodMajorCrossedTex);
				}
				else if (mood.CurLevelPercentage <= mb.BreakThresholdMinor)
				{
					GUI.DrawTexture(moodBorderRect, MoodMinorCrossedTex);
				}
			}
			// normal background...
			GUI.DrawTexture(rect, _ColonistBar.BGTex);

			// draw mood thingie
			Rect moodRect = rect.ContractedBy(2.0f);

			if (mood != null && mb != null)
			{
				if (mood.CurLevelPercentage > mb.BreakThresholdMinor)
				{
					GUI.DrawTexture(moodRect.BottomPart(mood.CurLevelPercentage), MoodTex);
				}
				else if (mood.CurLevelPercentage > mb.BreakThresholdMajor)
				{
					GUI.DrawTexture(moodRect.BottomPart(mood.CurLevelPercentage), MoodMinorCrossedTex);
				}
				else if (mood.CurLevelPercentage > mb.BreakThresholdExtreme)
				{
					GUI.DrawTexture(moodRect.BottomPart(mood.CurLevelPercentage), MoodMajorCrossedTex);
				}
				else {
					GUI.DrawTexture(moodRect, MoodExtremeCrossedBGTex);
					GUI.DrawTexture(moodRect.BottomPart(mood.CurLevelPercentage), MoodExtremeCrossedTex);
				}

				DrawMentalThreshold(moodRect, mb.BreakThresholdExtreme, mood.CurLevelPercentage);
				DrawMentalThreshold(moodRect, mb.BreakThresholdMajor, mood.CurLevelPercentage);
				DrawMentalThreshold(moodRect, mb.BreakThresholdMinor, mood.CurLevelPercentage);

				GUI.DrawTexture(new Rect(moodRect.x, moodRect.yMax - moodRect.height * mood.CurInstantLevelPercentage, moodRect.width, 1), MoodTargetTex);

				GUI.DrawTexture(new Rect(moodRect.xMax+1, moodRect.yMax - moodRect.height * mood.CurInstantLevelPercentage -1, 2, 3), MoodTargetTex);
			}

			if (flag)
			{
				InvokeOriginal("DrawSelectionOverlayOnGUI", cbar, new System.Object[] { colonist, rect.ContractedBy(-2f * scale) });
			}
			GUI.DrawTexture((Rect)InvokeOriginal("GetPawnTextureRect", cbar, new System.Object[] { rect.x, rect.y}),
			                PortraitsCache.Get(colonist, ColonistBar.PawnTextureSize, PawnTextureCameraOffset, 1.28205f));
			GUI.color = new Color(1f, 1f, 1f, colonistRectAlpha * 0.8f);
			InvokeOriginal("DrawIcons", cbar, new System.Object[]{rect, colonist});
			GUI.color = color;
			if (colonist.Dead)
			{
				GUI.DrawTexture(rect, _ColonistBar.DeadColonistTex);
			}
			float num = 4f * scale;
			Vector2 pos = new Vector2(rect.center.x, rect.yMax - num);
			GenWorldUI.DrawPawnLabel(colonist, pos, colonistRectAlpha, rect.width + SpacingHorizontalAssumingScale(scale) - 2f, (Dictionary<String,String>)GetOriginal("pawnLabelsCache", cbar));
			GUI.color = Color.white;
		}


	}
}

